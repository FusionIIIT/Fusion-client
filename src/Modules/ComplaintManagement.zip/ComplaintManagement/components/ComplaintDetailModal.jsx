import PropTypes from "prop-types";
import { Modal, Stack, Text } from "@mantine/core";

export default function ComplaintDetailModal({ opened, onClose, detail }) {
  return (
    <Modal opened={opened} onClose={onClose} title="Complaint Detail" centered>
      {!detail ? (
        <Text c="dimmed">No detail loaded.</Text>
      ) : (
        <Stack gap="xs">
          <Text><strong>ID:</strong> {detail.complaint_details?.id}</Text>
          <Text><strong>Type:</strong> {detail.complaint_details?.complaint_type}</Text>
          <Text><strong>Location:</strong> {detail.complaint_details?.location}</Text>
          <Text><strong>Status:</strong> {detail.complaint_details?.status}</Text>
          <Text><strong>Details:</strong> {detail.complaint_details?.details}</Text>
          <Text><strong>Complainer:</strong> {detail.complainer?.username}</Text>
          <Text><strong>Worker:</strong> {detail.worker_details?.name || "Not assigned"}</Text>
        </Stack>
      )}
    </Modal>
  );
}

ComplaintDetailModal.propTypes = {
  opened: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  detail: PropTypes.object,
};

ComplaintDetailModal.defaultProps = {
  detail: null,
};
