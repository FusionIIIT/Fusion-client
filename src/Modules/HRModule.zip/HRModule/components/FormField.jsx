const FormField = ({ label, name, type = 'text', value, onChange, required = false, ...rest }) => (
  <div className="fusion-field">
    <label className="fusion-label">
      {label}
      {required && <span className="ml-1 text-red-600">*</span>}
    </label>
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      required={required}
      className="fusion-input"
      {...rest}
    />
  </div>
);
export default FormField;