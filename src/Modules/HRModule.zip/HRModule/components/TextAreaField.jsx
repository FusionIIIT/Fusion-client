const TextAreaField = ({ label, name, value, onChange, required = false }) => (
  <div className="fusion-field">
    <label className="fusion-label">
      {label}
      {required && <span className="ml-1 text-red-600">*</span>}
    </label>
    <textarea
      name={name}
      value={value}
      onChange={onChange}
      required={required}
      rows="3"
      className="fusion-textarea"
    />
  </div>
);
export default TextAreaField;